"""
distributed_mnist.py
====================
Task 1 — Job 1: Distributed Handwritten Digit Classification using MPI
Course : HPC & Big Data Systems
Dataset: Sklearn Digits (1,797 samples, 64 features, classes 0-9)

How it works (Big Picture):
  - 6 MPI processes are launched across 3 VMs (2 processes per VM)
  - Rank 0 (master process) loads the data once, then broadcasts it to all ranks
  - Each rank independently trains a Random Forest on its slice of the data
  - All ranks send their accuracy score back to rank 0 (gather)
  - Rank 0 prints the combined results
"""

from mpi4py import MPI                              # MPI bindings for Python
from sklearn.datasets import load_digits            # Built-in sklearn digit image dataset
from sklearn.ensemble import RandomForestClassifier # ML model we will train
import numpy as np                                  # Numerical array operations

# ── MPI Setup ─────────────────────────────────────────────────────────────────
comm = MPI.COMM_WORLD       # COMM_WORLD = the global group of all MPI processes
rank = comm.Get_rank()      # Each process asks: "What is my unique ID?"  → 0..5
size = comm.Get_size()      # Total number of processes launched (should be 6)

# ── Step 1: Only rank 0 loads the dataset ─────────────────────────────────────
# Reason: loading data on every rank wastes memory; rank 0 acts as the data server
if rank == 0:
    print(f"[Rank 0] Loading Digits dataset...")
    digits = load_digits()          # Returns a Bunch object with .data and .target
    data   = digits.data            # Shape: (1797, 64) — 1797 images, 64 pixel features
    target = digits.target          # Shape: (1797,)   — label 0-9 for each image
    print(f"[Rank 0] Dataset loaded: {data.shape[0]} samples, {data.shape[1]} features")
else:
    data   = None   # Workers don't have data yet; they wait for broadcast
    target = None

# ── Step 2: Broadcast data from rank 0 to all other ranks ─────────────────────
# bcast sends the SAME object to every rank simultaneously
data   = comm.bcast(data,   root=0)   # root=0 means rank 0 is the sender
target = comm.bcast(target, root=0)

# ── Step 3: Each rank calculates its own data slice ───────────────────────────
# Simple round-robin partitioning: 1797 samples / 6 processes ≈ 299 each
chunk = len(data) // size               # Integer division: floor(1797/6) = 299
start = rank * chunk                    # Where my slice begins
# The last rank gets any remainder samples to avoid data loss
end   = start + chunk if rank != size - 1 else len(data)

print(f"[Rank {rank}] Processing samples {start}–{end-1} "
      f"({end - start} samples) on this process")

# ── Step 4: Train a Random Forest on the local data slice ─────────────────────
# Each rank trains independently — this is embarrassingly parallel ML
clf = RandomForestClassifier(
    n_estimators=100,   # 100 decision trees in the forest
    random_state=42     # Reproducible results
)
clf.fit(data[start:end], target[start:end])     # Train on this rank's slice

# Evaluate accuracy on the same slice (in-sample for demo purposes)
score = clf.score(data[start:end], target[start:end])
print(f"[Rank {rank}] Local accuracy: {score:.4f}")

# ── Step 5: Gather all scores back to rank 0 ──────────────────────────────────
# gather collects one value from each rank → rank 0 gets a list of 6 scores
scores = comm.gather(score, root=0)

# ── Step 6: Rank 0 prints the final combined results ──────────────────────────
if rank == 0:
    print("\n" + "="*55)
    print("  Distributed Digit Classification — Results")
    print("="*55)
    print(f"  Scores from all nodes: {[round(s, 4) for s in scores]}")
    print(f"  Average score        : {np.mean(scores):.4f}")
    print(f"  Min score            : {np.min(scores):.4f}")
    print(f"  Max score            : {np.max(scores):.4f}")
    print("="*55)
    print("  Job 1 COMPLETE — 6 MPI processes finished successfully")
    print("="*55)
