# Final Report — Mini-HPC & Hybrid HPC-Big Data Cluster

**Course**: HPC & Big Data Systems
**Programme**: Biotechnology
**Instructor**: Eng. Malak Soliman
**Date**: June 2025

---

## 1. Executive Summary

This project successfully built and operated two distributed computing systems on a single laptop using VirtualBox virtual machines:

1. A **Mini-HPC Cluster** using OpenMPI across 3 Ubuntu VMs, achieving distributed Machine Learning with 6 parallel processes. Two ML jobs were completed: digit classification (1,797 samples) and leukemia gene expression analysis (200 patient samples).

2. A **Hybrid Big Data Cluster** using Docker Swarm to orchestrate an Apache Spark cluster across the same 3 VMs, running a PySpark MLlib pipeline on the gene expression dataset with an 80/20 train-test split.

Both tasks demonstrated how parallelism dramatically reduces computation time, directly analogous to how many scientists can process more biological samples simultaneously than one scientist working alone.

---

## 2. Task 1 — Mini-HPC Cluster with MPI

### 2.1 Infrastructure Setup

Three Ubuntu 20.04 Server VMs were created in VirtualBox:

| Node | IP Address | Role | CPUs | RAM |
|------|-----------|------|------|-----|
| master | 192.168.56.10 | MPI Coordinator | 2 | 4 GB |
| worker1 | 192.168.56.11 | MPI Worker | 2 | 4 GB |
| worker2 | 192.168.56.12 | MPI Worker | 2 | 4 GB |

All nodes are connected via a VirtualBox Host-Only network (`vboxnet0`) with static IP addresses configured through Ubuntu's `netplan`. The `/etc/hosts` file on each node maps hostnames to IPs so MPI can locate workers by name rather than raw IP.

### 2.2 Passwordless SSH

OpenMPI requires passwordless SSH access from the master to all workers. An RSA key pair was generated on master with `ssh-keygen`, and the public key was distributed to workers with `ssh-copy-id`. This allows MPI to start remote processes on workers without human password input.

### 2.3 Software Stack

Installed on all 3 VMs:
- **OpenMPI 4.0.3** — the MPI engine (`mpirun` command)
- **mpi4py** — Python bindings to MPI
- **scikit-learn** — Random Forest classifier
- **pandas** — CSV data reading
- **numpy** — numerical array operations

### 2.4 Job 1 — Distributed Digit Classification

**Dataset**: Sklearn Digits — 1,797 handwritten digit images (0–9), 64 features each.

**Method**: The dataset was loaded on rank 0 and broadcast to all 6 ranks. Each rank trained an independent Random Forest (100 trees) on its ~299-sample slice, then scores were gathered at rank 0.

**Run command**:
```bash
mpirun -np 6 --hostfile hostfile python3 distributed_mnist.py
```

**Results**:

| Rank | Node | Samples | Accuracy |
|------|------|---------|----------|
| 0 | master | 299 | 1.0000 |
| 1 | master | 299 | 1.0000 |
| 2 | worker1 | 299 | 1.0000 |
| 3 | worker1 | 299 | 1.0000 |
| 4 | worker2 | 299 | 1.0000 |
| 5 | worker2 | 302 | 1.0000 |

**Average accuracy: 1.0000 (100%)** — All 6 processes classified their digit slices perfectly, demonstrating successful distributed training.

### 2.5 Job 2 — Distributed Bioinformatics Gene Expression Analysis

**Dataset**: `leukemia_expression.csv` — 200 patient samples, 50 gene expression features, binary label (`leukemia` / `normal`).

**Scientific Context**: Gene expression profiling is a real technique in computational oncology. The expression levels of thousands of genes are measured in a patient's cancer cells, and ML models classify whether the patient has leukemia. Our distributed approach lets a cluster process far more patient samples simultaneously than a single workstation.

**Method**: Same MPI structure as Job 1. Rank 0 reads the CSV with `pandas`, encodes string labels to integers with `LabelEncoder`, broadcasts to all ranks, and each rank trains on ~33 patients.

**Run command**:
```bash
mpirun -np 6 --hostfile hostfile python3 distributed_gene_analysis.py
```

**Results**:

| Rank | Node | Patients | Accuracy |
|------|------|---------|----------|
| 0 | master | 33 | 1.0000 |
| 1 | master | 33 | 1.0000 |
| 2 | worker1 | 33 | 1.0000 |
| 3 | worker1 | 33 | 1.0000 |
| 4 | worker2 | 33 | 1.0000 |
| 5 | worker2 | 35 | 1.0000 |

**Average accuracy: 1.0000 (100%)** — The gene expression features were sufficiently distinctive that each rank's Random Forest classified its patient subset with perfect accuracy. This demonstrates how HPC clusters can accelerate real biomedical data analysis.

---

## 3. Task 2 — Hybrid Big Data Cluster (Docker Swarm + Apache Spark)

### 3.1 Docker Swarm Setup

Docker was installed on all 3 VMs. The Swarm was initialized on master, and worker1 and worker2 joined as worker nodes:

```
$ docker node ls
ID          HOSTNAME   STATUS    AVAILABILITY  MANAGER STATUS
xxxx *      master     Ready     Active        Leader
yyyy        worker1    Ready     Active
zzzz        worker2    Ready     Active
```

### 3.2 Spark Cluster Deployment

The `spark-stack.yml` file deploys 3 Docker services:
- `spark-master` — pinned to the manager node (192.168.56.10), exposed on ports 8080 (Web UI) and 7077 (Spark protocol)
- `spark-worker-1` — pinned to worker1 (192.168.56.11)
- `spark-worker-2` — pinned to worker2 (192.168.56.12)

All services communicate over the Docker overlay network `spark-net`, which spans all 3 VMs transparently.

### 3.3 Differences from MPI (Task 1)

| Aspect | Task 1 (MPI) | Task 2 (Spark) |
|--------|-------------|----------------|
| Data distribution | Manual (bcast/gather) | Automatic (DataFrame partitions) |
| Fault tolerance | None | Yes (RDD lineage) |
| Programming model | Rank-based SPMD | Driver + Executors |
| Data scale | In-memory per rank | Can exceed single-node RAM |
| Monitoring | Terminal output | Web UI at port 8080 |
| Best for | Tightly coupled numerical computation | Large-scale data analytics |

### 3.4 PySpark ML Job Results

The `distributed_gene_expression_analysis.py` script used Spark's ML Pipeline:
1. **StringIndexer** — encodes `leukemia`/`normal` to 0/1
2. **VectorAssembler** — combines 50 gene columns into a feature vector
3. **RandomForestClassifier** — MLlib distributed Random Forest (100 trees)

An 80/20 train/test split was used (better practice than Job 1's in-sample evaluation).

| Metric | Value |
|--------|-------|
| Training samples | ~160 patients |
| Test samples | ~40 patients |
| Test Accuracy | 94.74% |
| F1 Score | 0.9474 |

The lower accuracy vs. Task 1 (100%) is expected and more realistic — this is a proper hold-out test evaluation, not in-sample scoring.

---

## 4. Concepts Learned

### 4.1 Parallel Computing Paradigms

This project exposed two fundamentally different approaches to distributed computing:

- **MPI (SPMD model)**: All processes run the same program simultaneously. They coordinate explicitly using collective operations (`bcast`, `gather`). Best for HPC workloads where data fits in RAM and tight synchronization is needed.

- **Spark (MapReduce/DAG model)**: A driver program orchestrates executors that process data partitions independently. Spark handles fault tolerance through RDD lineage — if a node fails, it can recompute lost partitions from the lineage graph.

### 4.2 Why Biotechnology Researchers Use HPC

Genomic analysis is computationally intensive. A whole-genome sequencing dataset can contain billions of reads, each requiring alignment against a 3-billion-base reference. Distributed computing allows:
- Parallel alignment of different chromosome regions
- Distributed training of ML classifiers on tens of thousands of patient gene expression profiles
- Faster hypothesis testing — analysis that takes days on a laptop takes hours on a cluster

### 4.3 Containerization Benefits (Docker Swarm)

Docker containers solve the "it works on my machine" problem. Each container carries its complete software environment. Docker Swarm distributes containers across the cluster, handles container restarts on failure, and provides service discovery so `spark-master` hostname resolves to the correct container IP automatically.

---

## 5. Challenges and Solutions

| Challenge | Solution |
|-----------|---------|
| SSH asked for password during MPI launch | Used `ssh-copy-id` to distribute public key; confirmed `ssh student@worker1` connected without password before running MPI |
| YAML indentation errors in netplan | Carefully used 2 spaces per indent level; never Tab key |
| Docker Swarm workers not registering in Spark UI | Waited 30 seconds after `docker stack deploy` for services to start; verified with `docker service ls` |
| PySpark accuracy lower than MPI result | This is correct — MPI jobs used in-sample scoring; Spark job used proper train/test split which gives an honest out-of-sample estimate |

---

## 6. Conclusion

Both cluster types were successfully built and operated:

- **Task 1**: 3-node MPI cluster ran 6 parallel processes achieving 100% in-sample accuracy on digit recognition and 100% on leukemia gene expression classification.
- **Task 2**: Docker Swarm deployed Apache Spark across 3 nodes; the PySpark ML pipeline achieved 94.74% accuracy on a held-out test set — a more realistic and scientifically valid evaluation.

The project demonstrated that distributed computing is accessible even on student laptops through virtualization, and that the same infrastructure skills used here apply directly to real HPC clusters and cloud computing environments that biotechnology researchers encounter in industry and academia.

---

*Submitted by: [Student Name(s)] — [Student ID(s)]*
