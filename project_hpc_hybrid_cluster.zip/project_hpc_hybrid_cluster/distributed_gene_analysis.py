"""
distributed_gene_analysis.py
============================
Task 1 — Job 2: Distributed Bioinformatics Gene Expression Analysis using MPI
Course : HPC & Big Data Systems
Dataset: leukemia_expression.csv (patient gene expression profiles)
         Columns: GENE_001 … GENE_050 (feature columns) + diagnosis (label column)
         Classes: 'leukemia' vs 'normal'

Scientific Context:
  Gene expression data measures the activity level of each gene in a patient's cells.
  Machine learning on this data can classify patients into disease categories —
  a real technique used in computational biology and precision medicine.

Parallel Strategy:
  Same embarrassingly parallel approach as Job 1:
  rank 0 loads and broadcasts the CSV data, each rank trains on its patient subset,
  scores are gathered at rank 0 for a final report.
"""

from mpi4py import MPI                              # MPI bindings for Python
import pandas as pd                                 # CSV reading and data frames
from sklearn.ensemble import RandomForestClassifier # ML model (same as Job 1)
from sklearn.preprocessing import LabelEncoder      # Convert string labels → integers
import numpy as np                                  # Numerical operations

# ── MPI Setup ─────────────────────────────────────────────────────────────────
comm = MPI.COMM_WORLD       # Global MPI communicator (all 6 processes)
rank = comm.Get_rank()      # This process's unique ID: 0, 1, 2, 3, 4, or 5
size = comm.Get_size()      # Total processes (6)

# ── Step 1: Rank 0 reads the CSV file ─────────────────────────────────────────
if rank == 0:
    print(f"[Rank 0] Reading leukemia_expression.csv...")
    df = pd.read_csv('bioinfo_data/leukemia_expression.csv')

    # All columns except the last are gene expression features (float values)
    data   = df.iloc[:, :-1].values   # Shape: (n_patients, n_genes) as numpy array

    # Last column is the string label ('leukemia' or 'normal')
    # LabelEncoder converts strings to integers: 'leukemia'→0, 'normal'→1 (alphabetical)
    le     = LabelEncoder()
    target = le.fit_transform(df.iloc[:, -1].values)  # Shape: (n_patients,)

    print(f"[Rank 0] Dataset: {data.shape[0]} patients, {data.shape[1]} genes")
    print(f"[Rank 0] Classes: {list(le.classes_)}  →  {list(range(len(le.classes_)))}")
else:
    data   = None   # Workers wait for the broadcast
    target = None

# ── Step 2: Broadcast data from rank 0 to all other ranks ─────────────────────
data   = comm.bcast(data,   root=0)   # All ranks now have the full dataset in memory
target = comm.bcast(target, root=0)

# ── Step 3: Partition the dataset across ranks ────────────────────────────────
chunk = len(data) // size                               # Patients per process
start = rank * chunk
end   = start + chunk if rank != size - 1 else len(data)

print(f"[Rank {rank}] Analysing patients {start}–{end-1} ({end - start} patients)")

# ── Step 4: Train Random Forest classifier on local patient subset ─────────────
clf = RandomForestClassifier(
    n_estimators=100,   # Ensemble of 100 decision trees
    random_state=42     # Fixed seed for reproducibility
)
clf.fit(data[start:end], target[start:end])     # Fit on this rank's patients

# Compute accuracy on this rank's data slice
score = clf.score(data[start:end], target[start:end])
print(f"[Rank {rank}] Local classification accuracy: {score:.4f}")

# ── Step 5: Gather all 6 accuracy scores back to rank 0 ───────────────────────
scores = comm.gather(score, root=0)

# ── Step 6: Rank 0 prints the bioinformatics summary ─────────────────────────
if rank == 0:
    print("\n" + "="*60)
    print("  Distributed Bioinformatics Gene Expression Analysis")
    print("="*60)
    print(f"  Bioinformatics scores from all nodes:")
    for i, s in enumerate(scores):
        print(f"    Rank {i}: {s:.4f} ({s*100:.2f}% accuracy)")
    print(f"\n  Average score : {np.mean(scores):.4f}")
    print(f"  Min score     : {np.min(scores):.4f}")
    print(f"  Max score     : {np.max(scores):.4f}")
    print("="*60)
    print("  Job 2 COMPLETE — Leukemia classification finished")
    print("  Distributed across 6 MPI processes on 3 virtual nodes")
    print("="*60)
