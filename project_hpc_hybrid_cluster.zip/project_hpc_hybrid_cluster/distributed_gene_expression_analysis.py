"""
distributed_gene_expression_analysis.py
=========================================
Task 2 — Distributed Bioinformatics ML with Apache Spark (PySpark)
Course : HPC & Big Data Systems
Dataset: leukemia_expression.csv

Differences from Task 1 (MPI):
  - Spark uses a Driver + Executors model instead of rank-based MPI processes
  - Data is automatically partitioned by Spark into RDD/DataFrame partitions
  - Spark MLlib handles distributed model training natively
  - The Spark Web UI (port 8080 on the manager node) shows live job progress
  - Suitable for very large datasets that don't fit in a single machine's RAM

Cluster Architecture (Docker Swarm):
  - 1 Spark Master container (manager node: 192.168.56.10)
  - 2 Spark Worker containers (worker1, worker2 nodes)
  - All connected via Docker overlay network 'spark-net'

Run from manager node after deploying the spark-stack.yml:
  docker exec -it <spark-master-container-id> \
    spark-submit \
    --master spark://spark-master:7077 \
    /data/distributed_gene_expression_analysis.py
"""

from pyspark.sql import SparkSession                          # Entry point for PySpark
from pyspark.sql.functions import col, when                   # DataFrame column operations
from pyspark.ml.feature import VectorAssembler, StringIndexer # Feature engineering
from pyspark.ml.classification import RandomForestClassifier  # Spark MLlib RF
from pyspark.ml.evaluation import MulticlassClassificationEvaluator  # Accuracy metrics
from pyspark.ml import Pipeline                               # Chain stages together

# ── Step 1: Create SparkSession connected to the cluster ──────────────────────
# The SparkSession is the driver; it connects to the master at spark://spark-master:7077
# Executors (worker processes) are started automatically on each worker node
spark = SparkSession.builder \
    .appName("Distributed_Leukemia_Gene_Expression_Analysis") \
    .master("spark://spark-master:7077") \
    .config("spark.executor.memory", "1g") \
    .config("spark.executor.cores", "1") \
    .getOrCreate()

# Lower log verbosity so our output is readable
spark.sparkContext.setLogLevel("WARN")

print("="*60)
print("  Distributed Gene Expression Analysis — PySpark")
print("="*60)
print(f"  Spark version  : {spark.version}")
print(f"  App name       : {spark.sparkContext.appName}")
print(f"  Master URL     : {spark.sparkContext.master}")
print("="*60)

# ── Step 2: Load the CSV dataset into a Spark DataFrame ───────────────────────
# Spark automatically distributes partitions across all executor nodes
# inferSchema=True → Spark reads a sample to detect column types automatically
print("\n[Driver] Loading leukemia_expression.csv into Spark DataFrame...")
df = spark.read.csv(
    "/data/bioinfo_data/leukemia_expression.csv",
    header=True,        # First row is the column header
    inferSchema=True    # Detect float types for gene columns, string for diagnosis
)

print(f"[Driver] Dataset loaded: {df.count()} rows × {len(df.columns)} columns")
print(f"[Driver] Columns (first 5): {df.columns[:5]}")
print(f"[Driver] Spark partitions  : {df.rdd.getNumPartitions()}")
df.show(5, truncate=True)   # Show first 5 rows for verification

# ── Step 3: Encode the label column 'diagnosis' → numeric index ───────────────
# Spark ML requires numeric labels; StringIndexer converts 'leukemia'→0, 'normal'→1
label_indexer = StringIndexer(
    inputCol="diagnosis",       # The string label column
    outputCol="label"           # New integer label column Spark ML expects
)

# ── Step 4: Assemble gene expression columns into a single feature vector ─────
# Spark MLlib expects features in a single Vector column called 'features'
gene_columns = [c for c in df.columns if c.startswith("GENE_")]  # All GENE_xxx columns
assembler = VectorAssembler(
    inputCols=gene_columns,     # List of gene expression columns
    outputCol="features"        # Output column: a DenseVector per row
)

# ── Step 5: Define the Spark MLlib Random Forest Classifier ───────────────────
rf = RandomForestClassifier(
    featuresCol="features",     # Input column (assembled in step 4)
    labelCol="label",           # Target column (encoded in step 3)
    numTrees=100,               # 100 decision trees in the ensemble
    seed=42                     # Reproducible results
)

# ── Step 6: Build a Pipeline — StringIndexer → VectorAssembler → RandomForest ─
# Pipelines chain preprocessing + model stages so they can be fit/transform together
pipeline = Pipeline(stages=[label_indexer, assembler, rf])

# ── Step 7: Split data into training (80%) and test (20%) sets ─────────────────
train_df, test_df = df.randomSplit([0.8, 0.2], seed=42)
print(f"\n[Driver] Train set: {train_df.count()} rows | Test set: {test_df.count()} rows")

# ── Step 8: Fit (train) the pipeline on the training data ─────────────────────
# Spark distributes the training across all worker executors automatically
print("[Driver] Training distributed Random Forest on cluster executors...")
model = pipeline.fit(train_df)
print("[Driver] Training complete!")

# ── Step 9: Make predictions on the test set ──────────────────────────────────
predictions = model.transform(test_df)
predictions.select("diagnosis", "label", "prediction", "probability") \
           .show(10, truncate=False)

# ── Step 10: Evaluate model accuracy on the held-out test set ─────────────────
evaluator = MulticlassClassificationEvaluator(
    labelCol="label",
    predictionCol="prediction",
    metricName="accuracy"       # Options: accuracy, f1, weightedPrecision, weightedRecall
)
accuracy = evaluator.evaluate(predictions)

# F1 score for a more complete picture
evaluator_f1 = MulticlassClassificationEvaluator(
    labelCol="label", predictionCol="prediction", metricName="f1"
)
f1 = evaluator_f1.evaluate(predictions)

print("\n" + "="*60)
print("  Final Evaluation on Test Set")
print("="*60)
print(f"  Test Accuracy : {accuracy:.4f}  ({accuracy*100:.2f}%)")
print(f"  F1 Score      : {f1:.4f}")
print("="*60)
print("  Task 2 COMPLETE — Distributed Spark ML job finished")
print("  Results produced by executors on worker1 and worker2")
print("="*60)

# ── Step 11: Stop the Spark session (releases cluster resources) ───────────────
spark.stop()
