# Mini-HPC & Hybrid HPC-Big Data Cluster

**HPC & Big Data Systems — Biotechnology Programme**
Instructor: Eng. Malak Soliman

---

## Project Overview

This project builds two complementary distributed computing clusters:

- **Task 1 — Mini-HPC Cluster**: 3 Ubuntu VMs connected via OpenMPI, running distributed Machine Learning jobs on a handwritten-digit dataset and a leukemia gene expression dataset.
- **Task 2 — Hybrid Big Data Cluster**: The same 3 VMs running Docker Swarm, hosting an Apache Spark cluster that performs distributed PySpark ML on the gene expression data.

---

## Cluster Architecture

```
Host Machine (Your Laptop)
└── VirtualBox
    ├── master   192.168.56.10   (MPI Coordinator / Docker Swarm Manager)
    ├── worker1  192.168.56.11   (MPI Worker / Docker Swarm Worker)
    └── worker2  192.168.56.12   (MPI Worker / Docker Swarm Worker)
```

All nodes share a VirtualBox Host-Only network (`vboxnet0`) — a private LAN visible only to the VMs and the host laptop.

---

## Repository Structure

```
project_hpc_hybrid_cluster/
├── README.md                              ← this file
├── hostfile                               ← MPI node list (Task 1)
├── distributed_mnist.py                   ← Task 1, Job 1: digit classifier
├── distributed_gene_analysis.py           ← Task 1, Job 2: bioinformatics ML
├── spark-stack.yml                        ← Task 2: Docker Swarm Spark deployment
├── distributed_gene_expression_analysis.py← Task 2: PySpark ML job
├── ml_job.slurm                           ← Optional SLURM job script
├── bioinfo_data/
│   └── leukemia_expression.csv            ← Gene expression dataset (200 patients, 50 genes)
├── screenshots/                           ← Evidence screenshots (see list below)
├── setup_log.txt                          ← Full command history and output log
└── Final_Report.pdf                       ← Final project report
```

---

## Quick Start

### Prerequisites (on each VM)

```bash
sudo apt update
sudo apt install openmpi-bin libopenmpi-dev python3 python3-pip -y
pip3 install mpi4py scikit-learn pandas numpy
```

### Task 1 — Run MPI Jobs

```bash
# From master VM — Job 1: Digit classification
mpirun -np 6 --hostfile hostfile python3 distributed_mnist.py

# From master VM — Job 2: Gene expression analysis
mpirun -np 6 --hostfile hostfile python3 distributed_gene_analysis.py
```

### Task 2 — Deploy Spark and Run PySpark Job

```bash
# 1. Initialize Docker Swarm (master VM only)
docker swarm init --advertise-addr 192.168.56.10

# 2. Join workers (run on worker1 and worker2 with token from above)
docker swarm join --token <TOKEN> 192.168.56.10:2377

# 3. Deploy Spark cluster
docker stack deploy -c spark-stack.yml spark

# 4. Wait for services to start
docker service ls

# 5. Submit PySpark job
MASTER_ID=$(docker ps -qf "name=spark_spark-master")
docker exec -it $MASTER_ID spark-submit \
    --master spark://spark-master:7077 \
    /data/distributed_gene_expression_analysis.py
```

**Spark Web UI**: http://192.168.56.10:8080

---

## Dataset

`bioinfo_data/leukemia_expression.csv`

| Property | Value |
|----------|-------|
| Rows | 200 patient samples |
| Feature columns | 50 gene expression values (GENE_001 … GENE_050) |
| Label column | `diagnosis` — `'leukemia'` or `'normal'` |
| Class balance | 100 leukemia / 100 normal |

---

## Expected Results

### Task 1 — MPI Jobs

| Metric | Job 1 (Digits) | Job 2 (Gene Expression) |
|--------|----------------|------------------------|
| MPI Processes | 6 | 6 |
| Samples per rank | ~299 | ~33 |
| Average accuracy | ~0.9952 | ~1.0000 |
| Model | Random Forest (100 trees) | Random Forest (100 trees) |

### Task 2 — PySpark

| Metric | Value |
|--------|-------|
| Spark workers | 2 |
| Total executor cores | 4 |
| Train/Test split | 80% / 20% |
| Test accuracy | ~94–100% |
| Model | Spark MLlib RandomForestClassifier |

---

## Screenshots Required

Place in the `screenshots/` folder:

1. `01_ip_a_master.png` — `ip a` output on master showing 192.168.56.10
2. `02_ip_a_worker1.png` — `ip a` output on worker1 showing 192.168.56.11
3. `03_ip_a_worker2.png` — `ip a` output on worker2 showing 192.168.56.12
4. `04_ssh_passwordless.png` — SSH to worker1 without password prompt
5. `05_mpi_job1_output.png` — Terminal output of distributed_mnist.py
6. `06_mpi_job2_output.png` — Terminal output of distributed_gene_analysis.py
7. `07_docker_node_ls.png` — `docker node ls` showing 3 active nodes
8. `08_spark_web_ui.png` — Spark Master UI at http://192.168.56.10:8080
9. `09_spark_job_output.png` — PySpark job terminal output

---

## Troubleshooting

| Error | Fix |
|-------|-----|
| `ping: unknown host worker1` | Add 3 lines to `/etc/hosts` on ALL VMs |
| `ssh: Connection refused` | `sudo systemctl start ssh && sudo systemctl enable ssh` |
| SSH asks for password | Re-run `ssh-copy-id student@worker1` |
| `mpirun: command not found` | `sudo apt install openmpi-bin -y` |
| `ModuleNotFoundError: mpi4py` | `pip3 install mpi4py` |
| `mpirun hangs` | Test `ssh student@worker1` manually first |
| `FileNotFoundError: leukemia_expression.csv` | `scp leukemia_expression.csv student@192.168.56.10:~/` |
| Docker swarm join fails | Check firewall: `sudo ufw allow 2377/tcp` |
| Spark workers not registering | Wait 30 seconds after `docker stack deploy` |

---

## Key Concepts

| Term | Definition |
|------|-----------|
| MPI | Message Passing Interface — protocol for programs running on multiple computers |
| rank | Each MPI process's unique ID number (0 = master process) |
| bcast | MPI Broadcast — rank 0 sends same data to all ranks simultaneously |
| gather | MPI Gather — all ranks send their result back to rank 0 |
| Docker Swarm | Container orchestration across multiple machines |
| Overlay network | Docker network that spans all Swarm nodes transparently |
| Spark Master | Coordinates Spark jobs; distributes tasks to executors |
| Spark Worker/Executor | Runs the actual computation on each node |
| Pipeline (Spark) | Chain of data transformations + model in a single object |
| VectorAssembler | Spark feature engineering: combines columns into one Vector |
